from distutils.core import setup

setup(
    name='indy',
    version='0.1b',
    packages=['indy', ],
    license='GNU',
    long_description=open('./README.md').read(),
    entry_points={
        'console_scripts': ['indy = indy:main']
    },
    install_requires=[]
)
